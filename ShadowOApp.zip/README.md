# ShadowOApp

ShadowOApp는 화면을 완전히 검게 만든 후, 터치 시 종료되는 아주 간단한 Android 유틸리티 앱입니다.

## 기능
- 앱 실행 시 전체 화면을 검게 표시
- 화면을 아무 곳이나 터치하면 앱 종료

## 설치 및 실행 방법

1. Android Studio에서 이 프로젝트를 엽니다.
2. `Build > Build APK(s)`를 선택해 APK를 빌드합니다.
3. 기기에 APK를 설치하고 실행합니다.

## 폴더 구조
```
ShadowOApp/
├── README.md
└── app/
    ├── build.gradle
    └── src/
        └── main/
            ├── AndroidManifest.xml
            ├── java/com/example/shadowo/MainActivity.kt
            └── res/layout/activity_main.xml
```
